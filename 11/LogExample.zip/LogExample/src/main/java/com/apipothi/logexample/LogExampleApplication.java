package com.apipothi.logexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LogExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogExampleApplication.class, args);
	}

}
